declare module 'utils' {
    const utils: any;
    export = utils;
  }
  
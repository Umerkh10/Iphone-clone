import { useEffect, useRef, useState } from "react"
import { hightlightsSlides } from "../constants"
import gsap from "gsap";
import { pauseImg, playImg, replayImg } from "../utils";

const VideoCarousel = () => {
    const videoRef = useRef<(HTMLVideoElement | null)[]>([]);
    const videoSpanRef = useRef<(HTMLSpanElement | null)[]>([]);
    const videoDivRef = useRef<(HTMLSpanElement | null)[]>([]);

    const [video, setVideo] = useState({
        isEnd: false,
        startPlay: false,
        videoId: 0,
        isLastVideo: false,
        isPlaying: false,
    });

    const [loadedData, setLoadedData] = useState([]);

    const { isEnd, isLastVideo, startPlay, videoId, isPlaying } = video;

    useEffect(() => {
        if (loadedData.length > 3) {
            if (!isPlaying) {
                videoRef.current[videoId]?.pause();
            } else {
                startPlay && videoRef.current[videoId]?.play()
            }
        }

    }, [startPlay, videoId, isPlaying, loadedData])

    useEffect(() => {
        const currentProgress = 0;
        let span = videoSpanRef.current;

        if (span[videoId]) {
            // animate the progress of the video
            let anim = gsap.to(span[videoId], {
                onUpdate: (() => {

                }),

                onComplete: (() => {

                }),
            })
        }

    }, [videoId, startPlay])

    const handleProcess = (type: string, i: number) => {
        switch (type) {
            case 'video-end':
                setVideo((prevVideo) => ({ ...prevVideo, isEnd: true , videoId: i+1 }));
                break;

            default:
                break;
        }
    };

    return (
        <>
            <div className="flex items-center">
                {hightlightsSlides.map((list, i) => (
                    <div key={list.id} id="slider" className="sm:pr-20 pr-10">
                        <div className="relative sm:w-[70vw] w-[88vw] md:h-[70vh] sm:h-[50vh] h-[35vh]">
                            <div className="w-full h-full flex items-center justify-center rounded-3xl overflow-hidden bg-black">
                                <video id="video" playsInline={true} preload="auto" muted
                                    ref={(el) => { videoRef.current[i] = el; }}
                                    onPlay={() => { setVideo((prevVideo) => ({ ...prevVideo, isPlaying: true })) }}>
                                    <source src={list.video} type="video/mp4" />
                                </video>
                            </div>
                            <div className="absolute top-12 left-[5%] z-10">
                                {list.textLists.map((text) => (
                                    <p key={text} className="md:text-2xl text-xl font-medium"> {text} </p>
                                ))}
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            <div className="relative flex justify-center items-center mt-10">
                <div className="flex justify-center items-center py-5 px-7 bg-zinc-800 backdrop-blur-md rounded-full">
                    {videoRef.current.map((_, i) => (
                        <span key={i} ref={(el) => { videoDivRef.current[i] = el; }}
                            className="mx-2 w-3 h-3 bg-gray-300 rounded-full relative cursor-pointer">
                            <span className="absolute h-full w-full rounded-full" ref={(el) => { videoSpanRef.current[i] = el; }}>   </span>
                        </span>
                    ))}
                </div>
                <button className="ml-4 p-4 rounded-full bg-gray-300 backdrop-blur-md flex justify-center items-center">
                    <img src={isLastVideo ? replayImg : !isPlaying ? playImg : pauseImg} onClick={
                        isLastVideo ? ( => handleProcess('video-reset')
                        ) : !isPlaying ? () => handleProcess('play')
                            : ? () => handleProcess('pause')} />
                </button>
            </div>


        </>
    )
}

export default VideoCarousel